
public class TestConstructors {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Game aGame = new Game();
		BoardGame aBoardGame = new BoardGame();
		Chess aChessGame = new Chess();
		System.out.println("------------------");
		aGame.start();
		aBoardGame.start();
		aChessGame.start();
		System.out.println("-------------------");
		
		aBoardGame.placeBoard();
		aChessGame.placeBoard();
		aChessGame.placeChessmen();
		
		Game theGame = new CardGame();
		theGame.start();
	}

}
